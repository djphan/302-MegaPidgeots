var searchData=
[
  ['dr',['DR',['../namespace_d_r.html',1,'']]]
];
