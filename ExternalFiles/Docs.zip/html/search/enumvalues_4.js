var searchData=
[
  ['unknown',['UNKNOWN',['../class_d_r_1_1_client_handler_callback.html#a7347e298442352f6649d553b94104332a8daccb3d0b9ecb14ff6715658e76873d',1,'DR::ClientHandlerCallback']]],
  ['update_5fdata',['UPDATE_DATA',['../class_d_r_1_1_client_handler_callback.html#a7347e298442352f6649d553b94104332a3a54f71a303b5d3b9cbf1bc6bf5fdf3f',1,'DR::ClientHandlerCallback']]],
  ['user',['USER',['../class_d_r_1_1_model.html#a12358bf0f171ec1cc857489e06d8ac74a765a652b5267e263e1bc99aebd31b62a',1,'DR::Model']]]
];
