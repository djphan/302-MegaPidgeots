var searchData=
[
  ['viewchange',['viewChange',['../class_d_r_1_1_projection_view.html#ae0f66b6387edc563de887827db4ca589',1,'DR::ProjectionView']]],
  ['viewupdatehandled',['viewUpdateHandled',['../class_d_r_1_1_projection_view.html#a95053244806d3751145a03790e5caa33',1,'DR::ProjectionView']]]
];
