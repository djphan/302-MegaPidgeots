var searchData=
[
  ['init_5fdata',['INIT_DATA',['../class_d_r_1_1_client_handler_callback.html#a7347e298442352f6649d553b94104332a2c08a04b3bb19c94d15fb1f49d316081',1,'DR::ClientHandlerCallback']]]
];
